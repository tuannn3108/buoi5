package com.example.tuan5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tuan5Application {

	public static void main(String[] args) {
		SpringApplication.run(Tuan5Application.class, args);
	}

}
