package com.example.tuan5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tuan5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
